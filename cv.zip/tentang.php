<?php session_start(); ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tentang Saya - CV Saya</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <nav class="sidebar">
        <div class="sidebar-header">
        <img src="foto.jpeg" alt="Foto Profil" class="sidebar-profile-pic">
            <h3>CV Digital</h3>
        </div>
        <ul>
            <li><a href="index.php">Beranda</a></li>
            <li><a href="tentang.php" class="active">Tentang Saya</a></li>
            <li><a href="pendidikan.php">Pendidikan</a></li>
            <li><a href="pengalaman.php">Pengalaman</a></li>
            <li><a href="kontak.php">Kontak</a></li>
            <li><a href="artikel.php">Artikel</a></li>
        </ul>

    </nav>
    <main class="content">
        <section class="card">
            <h2>Tentang Saya</h2>
            <p>
                Saya Rizky Setiawan, saya bersekolah di SMK NEGERI 1 BAWANG yang memilih jurusan Pengembangan Perangkat Lunank dan Gim(PPLG), saya masuk pada tahun pelajaran 2024/2025. Dan saya lulusan dari SMP NEGERI 1 BANJARNEGARA. Saya memilih jurusan ini supaya dapat mendapatkan pengalaman baru dalam mempelajari tentang dunia pemrograman dan juga dorongan dari orang tua.
        </section>
        <section class="card">
            <h2>Keahlian</h2>
            <ul class="skills">
                <li>PHP</li>
                <li>HTML</li>
                <li>CSS</li>
                <li>JavaScript</li>
            </ul>
        </section>
    </main>
    <script src="script.js"></script>
</body>
</html>