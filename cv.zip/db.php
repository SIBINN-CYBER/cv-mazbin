<?php
// File: db.php
// Konfigurasi untuk koneksi ke database

$host = 'localhost';    // Host database, biasanya 'localhost'
$dbname = 'cv_mazbinn'; // Nama database Anda
$user = 'root';         // Username database Anda (default XAMPP adalah 'root')
$pass = '';             // Password database Anda (default XAMPP adalah kosong)

try {
    // Membuat koneksi PDO
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $user, $pass);
    
    // Mengatur mode error PDO ke exception
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Mengatur mode fetch default ke associative array
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    
} catch (PDOException $e) {
    // Jika koneksi gagal, tampilkan pesan error dan hentikan skrip
    // Pada lingkungan produksi, sebaiknya jangan tampilkan detail error ke pengguna
    die("Koneksi ke database gagal: " . $e->getMessage());
}
?>
