document.addEventListener('DOMContentLoaded', function() {

    // --- Typing Effect Module ---
    // This function initializes the typing animation on the homepage.
    const initTypingEffect = () => {
        const typingElement = document.getElementById('typing-effect');
        // Only run if the typing element exists on the page
        if (typingElement) {
            const words = ["Web Developer", "Desainer Grafis", "Mahasiswa", "Pecinta Teknologi"];
            let wordIndex = 0;
            let charIndex = 0;
            let isDeleting = false;

            const type = () => {
                const currentWord = words[wordIndex];
                if (isDeleting) {
                    typingElement.textContent = currentWord.substring(0, charIndex - 1);
                    charIndex--;
                } else {
                    typingElement.textContent = currentWord.substring(0, charIndex + 1);
                    charIndex++;
                }

                if (!isDeleting && charIndex === currentWord.length) {
                    setTimeout(() => isDeleting = true, 2000);
                } else if (isDeleting && charIndex === 0) {
                    isDeleting = false;
                    wordIndex = (wordIndex + 1) % words.length;
                }

                const typingSpeed = isDeleting ? 100 : 200;
                setTimeout(type, typingSpeed);
            };
            type(); // Start the animation
        }
    };

    // --- Contact Form Module ---
    // This function handles the contact form submission and success modal.
    const initContactForm = () => {
        const contactForm = document.getElementById('contact-form');
        // Only run if the contact form exists on the page
        if (contactForm) {
            const successModal = document.getElementById('success-modal');
            
            contactForm.addEventListener('submit', function(event) {
                event.preventDefault(); // Prevent the page from reloading

                if (successModal) {
                    // Show the modal
                    successModal.classList.add('visible');

                    // Hide the modal and reset the form after a delay
                    setTimeout(() => {
                        successModal.classList.remove('visible');
                        contactForm.reset();
                    }, 2500);
                }
            });
        }
    };

    // Initialize all modules
    initTypingEffect();
    initContactForm();
});
