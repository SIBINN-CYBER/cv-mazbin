<?php session_start(); ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kontak - CV Saya</title>
    <link rel="stylesheet" href="style.css">
    <style>
        /* --- Gaya Modal Konfirmasi (Disematkan untuk Pengujian) --- */
        .modal-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.6);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 1000;
            opacity: 0;
            visibility: hidden;
            transition: opacity 0.3s ease, visibility 0.3s ease;
        }

        .modal-overlay.visible {
            opacity: 1;
            visibility: visible;
        }

        .modal-content {
            background-color: #ffffff;
            padding: 3rem 4rem;
            border-radius: 15px;
            text-align: center;
            position: relative; /* Diperlukan untuk positioning tombol close */
            transform: scale(0.9);
            transition: transform 0.3s ease;
        }

        .modal-close-btn {
            position: absolute;
            top: 10px;
            right: 15px;
            font-size: 2rem;
            color: #aaa;
            cursor: pointer;
            line-height: 1;
            transition: color 0.2s ease;
        }

        .modal-close-btn:hover {
            color: #333;
        }

        .modal-overlay.visible .modal-content {
            transform: scale(1);
        }

        .modal-content p {
            color: #333;
            font-size: 1.2rem;
            font-weight: 600;
            margin-top: 1rem;
        }

        /* Animasi Centang */
        .checkmark {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            display: block;
            stroke-width: 3;
            stroke: #4caf50;
            stroke-miterlimit: 10;
            margin: 0 auto;
            box-shadow: inset 0px 0px 0px #4caf50;
            animation: fill .4s ease-in-out .4s forwards, scale .3s ease-in-out .9s both;
        }

        .checkmark-circle {
            stroke-dasharray: 166;
            stroke-dashoffset: 166;
            stroke-width: 3;
            stroke-miterlimit: 10;
            stroke: #4caf50;
            fill: none;
            animation: stroke .6s cubic-bezier(0.65, 0, 0.45, 1) forwards;
        }

        .checkmark-check {
            transform-origin: 50% 50%;
            stroke-dasharray: 48;
            stroke-dashoffset: 48;
            stroke: #fff !important; /* Paksa warna centang menjadi putih */
            animation: stroke .3s cubic-bezier(0.65, 0, 0.45, 1) .8s forwards;
        }

        @keyframes stroke {
            100% {
                stroke-dashoffset: 0;
            }
        }

        @keyframes scale {
            0%, 100% {
                transform: none;
            }
            50% {
                transform: scale3d(1.1, 1.1, 1);
            }
        }

        @keyframes fill {
            100% {
                box-shadow: inset 0px 0px 0px 40px #4caf50;
            }
        }
    </style>
</head>
<body>
    <nav class="sidebar">
        <div class="sidebar-header">
         <img src="foto.jpeg" alt="Foto Profil" class="sidebar-profile-pic">       
              <h3>CV Digital</h3>
        </div>
        <ul>
            <li><a href="index.php">Beranda</a></li>
            <li><a href="tentang.php">Tentang Saya</a></li>
            <li><a href="pendidikan.php">Pendidikan</a></li>
            <li><a href="pengalaman.php">Pengalaman</a></li>
            <li><a href="kontak.php" class="active">Kontak</a></li>
            <li><a href="artikel.php">Artikel</a></li>
        </ul>
    </nav>
    <main class="content">
        <section class="card">
            <h2>Hubungi Saya</h2>
            <form id="contact-form" class="contact-form">
                <div class="form-group">
                    <label for="nama">Nama</label>
                    <input type="text" id="nama" name="nama" required>
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" required>
                </div>
                <div class="form-group">
                    <label for="pesan">Pesan</label>
                    <textarea id="pesan" name="pesan" rows="5" required></textarea>
                </div>
                <button type="submit" class="btn">Kirim Pesan</button>
            </form>
        </section>
        <section class="card">
            <h2>Media Sosial</h2>
            <div class="social-links">
                <a href="https://www.instagram.com/dhjak_?igsh=MnV4enAxNGtrZ3Vo" target="_blank">Instagram</a>
                <a href="https://github.com/SIBINN-CYBER/SIBINN-CYBER.github.io" target="_blank">GitHub</a>
                <a href="https://www.tiktok.com/@dhjak5?_t=ZS-8zDRoghvJfb&_r=1"  target="_blank">TikTok</a>
            </div>
        </section>

        <!-- Modal Konfirmasi -->
        <div id="success-modal" class="modal-overlay">
            <div class="modal-content">
                <span class="modal-close-btn">&times;</span>
                <svg class="checkmark" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 52 52">
                    <circle class="checkmark-circle" cx="26" cy="26" r="25" fill="none"/>
                    <path class="checkmark-check" fill="none" d="M14.1 27.2l7.1 7.2 16.7-16.8"/>
                </svg>
                <p>Pesan Terkirim</p>
            </div>
        </div>
    </main>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const contactForm = document.getElementById('contact-form');
            const successModal = document.getElementById('success-modal');
            const closeBtn = document.querySelector('.modal-close-btn');
            let hideTimeout; // Variabel untuk menyimpan timeout

            // Fungsi untuk menyembunyikan modal
            const hideModal = () => {
                successModal.classList.remove('visible');
            };

            if (contactForm && successModal && closeBtn) {
                contactForm.addEventListener('submit', function(event) {
                    event.preventDefault(); // Mencegah halaman reload

                    const formData = new FormData(contactForm);
                    const data = {
                        nama: formData.get('nama'),
                        email: formData.get('email'),
                        pesan: formData.get('pesan')
                    };

                    // Kirim data ke backend
                    fetch('save_message.php', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify(data)
                    })
                    .then(response => response.json())
                    .then(result => {
                        if (result.success) {
                            // Jika sukses, tampilkan modal
                            successModal.classList.add('visible');
                            clearTimeout(hideTimeout);
                            hideTimeout = setTimeout(() => {
                                hideModal();
                                contactForm.reset();
                            }, 3000);
                        } else {
                            // Jika gagal, tampilkan pesan error
                            alert('Gagal mengirim pesan: ' + result.message);
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        alert('Terjadi kesalahan koneksi.');
                    });
                });

                // Event listener untuk tombol close (X)
                closeBtn.addEventListener('click', () => {
                    clearTimeout(hideTimeout);
                    hideModal();
                    contactForm.reset();
                });

                // Event listener untuk klik di luar area modal
                successModal.addEventListener('click', function(event) {
                    if (event.target === successModal) {
                        clearTimeout(hideTimeout);
                        hideModal();
                        contactForm.reset();
                    }
                });
            }
        });
    </script>
</body>
</html>