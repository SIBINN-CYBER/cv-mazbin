<?php session_start(); ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pendidikan - CV Saya</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <nav class="sidebar">
        <div class="sidebar-header">
        <img src="foto.jpeg" alt="Foto Profil" class="sidebar-profile-pic">
            <h3>CV Digital</h3>
        </div>
        <ul>
            <li><a href="index.php">Beranda</a></li>
            <li><a href="tentang.php">Tentang Saya</a></li>
            <li><a href="pendidikan.php" class="active">Pendidikan</a></li>
            <li><a href="pengalaman.php">Pengalaman</a></li>
            <li><a href="kontak.php">Kontak</a></li>
            <li><a href="artikel.php">Artikel</a></li>
        </ul>

    </nav>
    <main class="content">
        <section class="card">
            <h2>Riwayat Pendidikan</h2>
            <div class="timeline">
                <div class="timeline-item">
                    <h3>SMK NEGERI 1 BAWANG</h3>
                    <p><strong>Rekayasa Perangkat Lunak (RPL/PPLG)</strong> | 2024 - Sekarang</p>
                    <p>Mempelajari pengembangan aplikasi, sistem basis data, dan rekayasa perangkat lunak.</p>
                </div>
                <div class="timeline-item">
                    <h3>SMP NEGERI 1 BANJARNEGARA</h3>
                    <p>2021 - 2024</p>
                </div>
                <div class="timeline-item">
                    <h3>SD NEGERI 1 KALILUNJAR</h3>
                    <p>2015 - 2021</p>
                </div>
            </div>
        </section>
    </main>
    <script src="script.js"></script>
</body>
</html>