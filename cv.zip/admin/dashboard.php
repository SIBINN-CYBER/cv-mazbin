<?php
session_start();
// Jika tidak ada sesi login, kembalikan ke halaman login
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

require_once '../db.php';

// Ambil nama admin dari session
$username = $_SESSION['username'] ?? 'Admin';

?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="../style.css">
    <style>
        .content {
            display: block;
        }
        .dashboard-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem;
            margin-top: 2rem;
        }
        .dashboard-card {
            background-color: var(--surface-color);
            padding: 1.5rem;
            border-radius: 8px;
            border: 1px solid var(--border-color);
            text-decoration: none;
            color: var(--text-color);
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }
        .dashboard-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 20px rgba(0,0,0,0.2);
        }
        .dashboard-card h3 {
            color: var(--primary-color);
            margin-bottom: 0.5rem;
        }
        .dashboard-card p {
            color: var(--text-secondary-color);
            font-size: 0.9rem;
        }
    </style>
</head>
<body>
    <nav class="sidebar">
        <div class="sidebar-header">
            <h3>Admin Panel</h3>
        </div>
        <ul>
            <li><a href="manage_article.php">Manajemen Artikel</a></li>
            <li><a href="pesan.php">Pesan Masuk</a></li>
            <li><a href="../index.php" target="_blank">Lihat Website</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </nav>

    <main class="content">
        <section class="card">
            <h2>Selamat Datang, <?php echo htmlspecialchars($username); ?>!</h2>
            <p>Pilih salah satu menu di bawah atau di samping untuk mulai mengelola website Anda.</p>
        </section>

        <div class="dashboard-grid">
            <a href="manage_article.php" class="dashboard-card">
                <h3>Manajemen Artikel</h3>
                <p>Tambah, edit, atau hapus artikel di website Anda.</p>
            </a>
            <a href="pesan.php" class="dashboard-card">
                <h3>Pesan Masuk</h3>
                <p>Lihat semua pesan yang dikirim oleh pengunjung.</p>
            </a>
        </div>
    </main>
</body>
</html>