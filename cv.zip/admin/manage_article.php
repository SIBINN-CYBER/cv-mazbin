<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

require_once '../db.php';

$page_title = 'Tambah Artikel Baru';
$article = ['id' => '', 'title' => '', 'content' => ''];
$is_edit = false;

// Cek apakah ini mode edit
if (isset($_GET['id'])) {
    $is_edit = true;
    $article_id = $_GET['id'];
    $stmt = $pdo->prepare("SELECT * FROM articles WHERE id = ?");
    $stmt->execute([$article_id]);
    $article = $stmt->fetch();

    if (!$article) {
        // Jika artikel tidak ditemukan, kembali ke dashboard
        header("Location: dashboard.php");
        exit;
    }
    $page_title = 'Edit Artikel';
}

// Proses form saat disubmit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'];
    $content = $_POST['content'];

    if (empty($title) || empty($content)) {
        $error = "Judul dan konten tidak boleh kosong.";
    } else {
        if ($is_edit) {
            // Update artikel yang ada
            $stmt = $pdo->prepare("UPDATE articles SET title = ?, content = ? WHERE id = ?");
            $stmt->execute([$title, $content, $article_id]);
        } else {
            // Masukkan artikel baru
            $stmt = $pdo->prepare("INSERT INTO articles (title, content) VALUES (?, ?)");
            $stmt->execute([$title, $content]);
        }
        // Kembali ke dashboard setelah berhasil
        header("Location: dashboard.php");
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - CV Digital</title>
    <link rel="stylesheet" href="../style.css">
     <style>
        .content {
            display: block; /* Override flex-behavior */
            width: calc(100% - var(--sidebar-width));
        }
    </style>
</head>
<body>
    <nav class="sidebar">
        <div class="sidebar-header">
            <h3>Admin Panel</h3>
        </div>
        <ul>
            <li><a href="manage_article.php" class="active">Manajemen Artikel</a></li>
            <li><a href="pesan.php">Pesan Masuk</a></li>
            <li><a href="../index.php" target="_blank">Lihat Website</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </nav>

    <main class="content">
        <section class="card">
            <h2><?php echo $page_title; ?></h2>
            <?php if (isset($error)): ?>
                <p style="color: #ff6b6b; margin-bottom: 1rem;"><?php echo htmlspecialchars($error); ?></p>
            <?php endif; ?>
            <form method="POST" action="manage_article.php<?php echo $is_edit ? '?id='.$article_id : ''; ?>" class="contact-form">
                <div class="form-group">
                    <label for="title">Judul</label>
                    <input type="text" id="title" name="title" value="<?php echo htmlspecialchars($article['title']); ?>" required>
                </div>
                <div class="form-group">
                    <label for="content">Konten</label>
                    <textarea id="content" name="content" rows="10" required><?php echo htmlspecialchars($article['content']); ?></textarea>
                </div>
                <button type="submit" class="btn"><?php echo $is_edit ? 'Update Artikel' : 'Simpan Artikel'; ?></button>
                <a href="dashboard.php" style="margin-left: 1rem; color: var(--text-secondary-color-dark);">Batal</a>
            </form>
        </section>
    </main>

    <script src="../script.js"></script>
</body>
</html>
