<?php
session_start();
require_once 'db.php';

$is_detail_view = false;

if (isset($_GET['id']) && !empty($_GET['id'])) {
    // --- TAMPILAN DETAIL (SATU ARTIKEL) ---
    $is_detail_view = true;
    $article_id = $_GET['id'];
    $stmt = $pdo->prepare("SELECT * FROM articles WHERE id = ?");
    $stmt->execute([$article_id]);
    $article = $stmt->fetch();

    // Jika artikel dengan ID tersebut tidak ada, kembalikan ke daftar artikel
    if (!$article) {
        header("Location: artikel.php");
        exit;
    }
} else {
    // --- TAMPILAN DAFTAR (SEMUA ARTIKEL) ---
    $stmt = $pdo->query("SELECT * FROM articles ORDER BY created_at DESC");
    $articles = $stmt->fetchAll();
    $total_articles = count($articles);
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $is_detail_view ? htmlspecialchars($article['title']) : 'Artikel'; ?> - CV Digital</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .content {
            display: block; /* Override flex behavior */
        }
        .article-content p {
            white-space: pre-wrap; /* Menjaga format paragraf dan baris baru */
            line-height: 1.7;
        }
    </style>
</head>
<body>
    <nav class="sidebar">
        <div class="sidebar-header">
            <img src="foto.jpeg" alt="Foto Profil" class="sidebar-profile-pic">
            <h3>CV Digital</h3>
        </div>
        <ul>
            <li><a href="index.php">Beranda</a></li>
            <li><a href="tentang.php">Tentang Saya</a></li>
            <li><a href="pendidikan.php">Pendidikan</a></li>
            <li><a href="pengalaman.php">Pengalaman</a></li>
            <li><a href="kontak.php">Kontak</a></li>
            <li><a href="artikel.php" class="active">Artikel</a></li>
        </ul>

    </nav>

    <main class="content">

        <?php if ($is_detail_view): ?>
            <!-- Tampilan untuk satu artikel -->
            <article class="card">
                <h2><?php echo htmlspecialchars($article['title']); ?></h2>
                <p class="meta">Diposting pada <?php echo date('d F Y, H:i', strtotime($article['created_at'])); ?></p>
                <div class="article-content">
                    <p><?php echo nl2br(htmlspecialchars($article['content'])); ?></p>
                </div>
                <a href="artikel.php" style="margin-top: 2rem; display: inline-block; text-decoration: none; color: var(--primary-color);">&larr; Kembali ke Daftar Artikel</a>
            </article>

        <?php else: ?>
            <!-- Tampilan untuk daftar semua artikel -->
            <section class="card article-page-header">
                <h2>Artikel Terbaru</h2>
                <span class="article-count-badge">Total Artikel: <?php echo $total_articles; ?></span>
            </section>

            <?php if (empty($articles)): ?>
                <section class="card">
                    <p>Belum ada artikel yang dipublikasikan.</p>
                </section>
            <?php else: ?>
                <?php foreach ($articles as $list_item): ?>
                    <article class="card article-card">
                        <h3>
                            <a href="artikel.php?id=<?php echo $list_item['id']; ?>">
                                <?php echo htmlspecialchars($list_item['title']); ?>
                            </a>
                        </h3>
                        <p class="meta">Diposting pada <?php echo date('d F Y', strtotime($list_item['created_at'])); ?></p>
                    </article>
                <?php endforeach; ?>
            <?php endif; ?>

        <?php endif; ?>

    </main>

    <script src="script.js"></script>
</body>
</html>