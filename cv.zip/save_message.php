<?php
require_once 'db.php';

// Set header untuk merespons sebagai JSON
header('Content-Type: application/json');

// Ambil data JSON yang dikirim dari JavaScript
$data = json_decode(file_get_contents('php://input'), true);

// Validasi data
if (empty($data['nama']) || empty($data['email']) || empty($data['pesan'])) {
    // Kirim respons error jika ada data yang kosong
    echo json_encode(['success' => false, 'message' => 'Semua field harus diisi.']);
    exit;
}

if (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
    // Kirim respons error jika email tidak valid
    echo json_encode(['success' => false, 'message' => 'Format email tidak valid.']);
    exit;
}

try {
    // Siapkan statement SQL untuk memasukkan data
    $stmt = $pdo->prepare("INSERT INTO messages (name, email, message) VALUES (?, ?, ?)");
    
    // Eksekusi statement dengan data yang sudah divalidasi
    $stmt->execute([$data['nama'], $data['email'], $data['pesan']]);

    // Kirim respons sukses
    echo json_encode(['success' => true, 'message' => 'Pesan berhasil disimpan.']);

} catch (PDOException $e) {
    // Kirim respons error jika terjadi masalah dengan database
    // Sebaiknya jangan tampilkan $e->getMessage() di lingkungan produksi
    echo json_encode(['success' => false, 'message' => 'Gagal menyimpan pesan ke database.']);
}
?>