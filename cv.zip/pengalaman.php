<?php session_start(); ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pengalaman - CV Saya</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <nav class="sidebar">
        <div class="sidebar-header">
         <img src="foto.jpeg" alt="Foto Profil" class="sidebar-profile-pic">
            <h3>CV Digital</h3>
        </div>
        <ul>
            <li><a href="index.php">Beranda</a></li>
            <li><a href="tentang.php">Tentang Saya</a></li>
            <li><a href="pendidikan.php">Pendidikan</a></li>
            <li><a href="pengalaman.php" class="active">Pengalaman</a></li>
            <li><a href="kontak.php">Kontak</a></li>
            <li><a href="artikel.php">Artikel</a></li>
        </ul>

    </nav>
    <main class="content">
        <section class="card">
            <h2>Pengalaman Proyek & Pelatihan</h2>
            <div class="timeline">
                <div class="timeline">
                <div class="timeline-item">
                    <h3>Program Kalkulator C#</h3>
                    <ul>
                        <li>Membuat program C# yaitu kalkulator sederhana dengan antarmuka pengguna dasar.</li>
                    </ul>
                </div>
                <div class="timeline-item">
                    <h3>Proyek Aplikasi Login</h3>
                    <ul>
                        <li>Membuat proyek aplikasi halaman login untuk studi kasus sebuah kebun binatang.</li>
                    </ul>
                </div>
                <div class="timeline-item">
                    <h3>Pelatihan Coding & Database</h3>
                    <ul>
                        <li>Mengikuti pelatihan intensif tentang implementasi coding dan database siap pakai.</li>
                    </ul>
                </div>
            </div>
            </div>
        </section>
    </main>
    <script src="script.js"></script>
</body>
</html>