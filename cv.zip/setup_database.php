<?php
require_once 'db.php';

try {
    $sql = "CREATE TABLE IF NOT EXISTS messages (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        email VARCHAR(100) NOT NULL,
        message TEXT NOT NULL,
        received_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";

    $pdo->exec($sql);

    echo "Tabel 'messages' berhasil dibuat atau sudah ada.";

} catch (PDOException $e) {
    die("Gagal membuat tabel: " . $e->getMessage());
}
?>